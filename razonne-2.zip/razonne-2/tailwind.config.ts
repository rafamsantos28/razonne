import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        void: "#07080b",
        panel: "#0f1216",
        chrome: "#c9d2da",
        teal: {
          DEFAULT: "#2be3e0",
          dim: "#16787a"
        },
        magenta: {
          DEFAULT: "#ff5fb8",
          dim: "#9a2c68"
        }
      },
      fontFamily: {
        display: ["var(--font-display)"],
        body: ["var(--font-body)"]
      },
      backgroundImage: {
        "razonne-gradient":
          "linear-gradient(135deg, #2be3e0 0%, #c9d2da 45%, #ff5fb8 100%)",
        "razonne-glow":
          "radial-gradient(60% 60% at 50% 0%, rgba(43,227,224,0.18) 0%, rgba(255,95,184,0.10) 45%, rgba(7,8,11,0) 80%)"
      }
    }
  },
  plugins: []
};

export default config;
