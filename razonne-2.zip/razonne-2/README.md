# Razonne+

Plataforma de streaming pessoal — tudo alojado na Vercel (base de dados,
imagens, contas) e os vídeos alojados no Mux, com um design inspirado nas
plataformas de streaming tradicionais e as cores da tua marca.

## O que já funciona

- Ecrã inicial → seleção de perfis (até 5, com avatares novos e leves,
  incluindo perfis infantis opcionais)
- Catálogo com destaque no topo + filas por categoria/género
- Página de cada filme, com sinopse, classificação etária, botão de
  reprodução e "+ Minha lista"
- Reprodutor de vídeo Mux (streaming adaptativo, sem precisares de tratar
  de compressão/formatos)
- Progresso de visualização guardado automaticamente (fila "Continuar a ver")
- Pesquisa por título, género ou sinopse
- Conta é **opcional**: sem conta, tudo funciona (identificado por um
  cookie criado automaticamente), mas os perfis/lista/progresso ficam só
  neste dispositivo — só criando conta (email + palavra-passe) é que
  sincronizam entre plataformas
- Painel **/admin** para adicionar, editar e apagar filmes: título e
  descrição são o único campo obrigatório — **poster, banner e vídeo podem
  ser adicionados a qualquer momento depois**, diretamente do browser

Toda a stack corre em serviços da Vercel: **Postgres** (catálogo, perfis,
contas, progresso), **Blob** (posters/banners) e **NextAuth** (sessões de
conta). O único serviço externo é o **Mux**, só para vídeo.

## 1. Instalar

```bash
npm install
```

## 2. Ligar os serviços da Vercel ao projeto

No dashboard da Vercel, dentro do teu projeto:

1. **Storage → Create Database → Postgres** — cria e liga ao projeto.
   Isto define a variável `POSTGRES_URL` sozinho.
2. **Storage → Create Database → Blob** — cria e liga ao projeto. Isto
   define `BLOB_READ_WRITE_TOKEN` sozinho.

As tabelas (`users`, `profiles`, `titles`, `watch_progress`, `my_list`) são
criadas automaticamente no primeiro pedido ao site — não precisas de correr
nada manualmente. Se preferires criá-las já, com a Postgres ligada, corre:

```bash
vercel env pull .env.local
npm run db:migrate
```

## 3. Configurar o Mux (vídeo)

1. Cria conta em [mux.com](https://mux.com) se ainda não tiveres.
2. **Settings → Access Tokens → Generate new token**, com permissão **Mux
   Video** (read/write). Copia o **Token ID** e o **Token Secret**.
3. Define `MUX_TOKEN_ID` e `MUX_TOKEN_SECRET` em Project Settings →
   Environment Variables na Vercel.
4. (Opcional) **Settings → Webhooks → Add new webhook**, com o URL
   `https://<o-teu-dominio>/api/mux/webhook`. Copia o **Signing secret**
   para `MUX_WEBHOOK_SECRET`. Sem isto, o painel /admin continua a
   funcionar na mesma (consulta o estado do vídeo automaticamente
   enquanto o browser está aberto) — o webhook só é útil se fechares o
   browser a meio do processamento.

## 4. Contas e administrador

1. Gera um segredo aleatório para `NEXTAUTH_SECRET`:
   ```bash
   openssl rand -base64 32
   ```
2. Define `NEXTAUTH_URL` como o URL público do site em produção (em
   localhost não precisas).
3. Define `ADMIN_EMAILS` com o(s) email(s) que vão ter acesso ao painel
   `/admin` (separados por vírgula). Depois de definires isto, cria uma
   conta em `/login` com esse email — fica automaticamente com acesso de
   administrador, não precisas de nenhum passo extra.

## 5. Correr localmente

```bash
vercel env pull .env.local   # traz as variáveis já definidas na Vercel
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000).

## 6. Publicar na Vercel

```bash
vercel deploy --prod
```

(ou liga o repositório Git ao projeto na Vercel para deploy automático a
cada push). Confirma que todas as variáveis de ambiente acima estão
definidas em Project Settings → Environment Variables antes do deploy.

## 7. Adicionar o filme de teste (Leviticus)

1. Inicia sessão com o teu email de administrador.
2. Vai a `/admin` → **+ Adicionar filme**.
3. Preenche:
   - **Título:** Leviticus
   - **Classificação etária:** 16+
   - **Géneros:** Terror
   - **Duração (minutos):** 88
   - **Ano:** 2026
   - **Descrição:** Ambientada numa comunidade cristã isolada e
     conservadora na Austrália, a história acompanha dois adolescentes,
     Naim e Ryan, que descobrem estar apaixonados um pelo outro.
4. Guarda — és levado automaticamente para a página de edição do filme.
5. Aí, envia o **poster**, o **banner** e o **vídeo** (o ficheiro que já
   tens preparado). O vídeo fica com o estado "A processar no Mux…" durante
   alguns minutos (depende da duração/tamanho do ficheiro) e muda sozinho
   para "Pronto ✓" assim que o Mux terminar — não precisas de recarregar a
   página.

## Sobre o bug do ecrã de perfis

Antes, depois de clicares em "Criar" no ecrã de criar perfil, o site ficava
preso porque a conta anónima do Firebase estava a falhar silenciosamente
(faltava configuração), e o `createProfile` não fazia nada. Agora o perfil
é criado através da API própria do site (Postgres na Vercel), seleciona-se
automaticamente e avança logo para o catálogo assim que é guardado com
sucesso.
