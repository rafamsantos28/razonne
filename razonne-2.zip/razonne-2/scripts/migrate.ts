/**
 * Cria as tabelas na base de dados Postgres da Vercel (Storage → Postgres).
 * Corre automaticamente durante o build (ver `vercel-build` em package.json),
 * mas também podes correr manualmente com:
 *
 *   npm run db:migrate
 *
 * Precisa da variável de ambiente POSTGRES_URL definida (a Vercel define-a
 * sozinha quando ligas uma base de dados Postgres ao projeto).
 */
import { sql } from "@vercel/postgres";

async function migrate() {
  await sql`
    CREATE TABLE IF NOT EXISTS users (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS profiles (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      owner_id TEXT NOT NULL,
      name TEXT NOT NULL,
      avatar TEXT NOT NULL,
      is_kids BOOLEAN NOT NULL DEFAULT false,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;
  await sql`CREATE INDEX IF NOT EXISTS profiles_owner_idx ON profiles (owner_id);`;

  await sql`
    CREATE TABLE IF NOT EXISTS titles (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      poster_url TEXT NOT NULL DEFAULT '',
      backdrop_url TEXT NOT NULL DEFAULT '',
      mux_asset_id TEXT,
      mux_playback_id TEXT,
      mux_upload_id TEXT,
      mux_status TEXT NOT NULL DEFAULT 'sem_video',
      genres TEXT[] NOT NULL DEFAULT '{}',
      year INTEGER,
      duration_minutes INTEGER,
      age_rating TEXT,
      category TEXT NOT NULL DEFAULT 'Em alta',
      featured BOOLEAN NOT NULL DEFAULT false,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS watch_progress (
      profile_id UUID NOT NULL,
      title_id UUID NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
      seconds DOUBLE PRECISION NOT NULL DEFAULT 0,
      duration_seconds DOUBLE PRECISION NOT NULL DEFAULT 0,
      updated_at BIGINT NOT NULL,
      PRIMARY KEY (profile_id, title_id)
    );
  `;

  await sql`
    CREATE TABLE IF NOT EXISTS my_list (
      profile_id UUID NOT NULL,
      title_id UUID NOT NULL REFERENCES titles(id) ON DELETE CASCADE,
      added_at BIGINT NOT NULL,
      PRIMARY KEY (profile_id, title_id)
    );
  `;

  console.log("[razonne] Migração concluída — tabelas prontas.");
}

migrate()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error("[razonne] Falha na migração:", err);
    process.exit(1);
  });
