"use client";

import { useEffect, useRef } from "react";
import MuxPlayer from "@mux/mux-player-react";
import { saveWatchProgress } from "@/lib/catalog";
import type { Title } from "@/lib/types";

export default function VideoPlayer({
  title,
  startAt = 0,
  activeProfileId
}: {
  title: Title;
  startAt?: number;
  activeProfileId: string;
}) {
  const playerRef = useRef<any>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      const el = playerRef.current;
      if (!el || el.paused || el.ended) return;
      saveWatchProgress(activeProfileId, {
        titleId: title.id,
        seconds: el.currentTime,
        durationSeconds: el.duration || 0,
        updatedAt: Date.now()
      });
    }, 10000);

    return () => {
      clearInterval(interval);
      const el = playerRef.current;
      if (el && el.currentTime > 0) {
        saveWatchProgress(activeProfileId, {
          titleId: title.id,
          seconds: el.currentTime,
          durationSeconds: el.duration || 0,
          updatedAt: Date.now()
        });
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [title.id, activeProfileId]);

  return (
    <MuxPlayer
      ref={playerRef}
      playbackId={title.muxPlaybackId!}
      streamType="on-demand"
      startTime={startAt}
      metadata={{ video_title: title.title, video_id: title.id }}
      autoPlay
      className="h-full w-full"
      accentColor="#2be3e0"
      style={{ width: "100%", height: "100%" }}
    />
  );
}
