"use client";

import Image from "next/image";
import Link from "next/link";
import type { Title } from "@/lib/types";

export default function Hero({ title }: { title: Title }) {
  const image = title.backdrop || title.poster;
  return (
    <div className="relative h-[62vh] min-h-[420px] w-full bg-panel md:h-[78vh]">
      {image && (
        <Image
          src={image}
          alt={title.title}
          fill
          priority
          className="object-cover object-top"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-void via-void/30 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-void/80 via-void/10 to-transparent" />

      <div className="absolute bottom-10 left-4 max-w-xl md:bottom-20 md:left-10">
        <p className="mb-2 font-display text-xs uppercase tracking-[0.3em] text-teal">
          Em destaque na Razonne+
        </p>
        <h1 className="font-display text-3xl font-bold leading-tight text-white drop-shadow-lg md:text-6xl">
          {title.title}
        </h1>
        <p className="mt-4 line-clamp-3 text-sm text-chrome/90 md:text-base">
          {title.description}
        </p>
        <div className="mt-6 flex gap-3">
          <Link
            href={`/watch/${title.id}`}
            className="flex items-center gap-2 rounded bg-white px-6 py-2.5 font-medium text-black transition hover:bg-white/85"
          >
            ▶ Reproduzir
          </Link>
          <Link
            href={`/title/${title.id}`}
            className="flex items-center gap-2 rounded bg-chrome/20 px-6 py-2.5 font-medium text-white backdrop-blur transition hover:bg-chrome/30"
          >
            Mais informações
          </Link>
        </div>
      </div>
    </div>
  );
}
