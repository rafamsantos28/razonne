"use client";

import Image from "next/image";
import Link from "next/link";
import type { Title } from "@/lib/types";

export default function MovieCard({ title }: { title: Title }) {
  return (
    <Link
      href={`/title/${title.id}`}
      className="group relative aspect-[2/3] w-[150px] shrink-0 overflow-hidden rounded-md bg-panel transition-transform duration-300 ease-out hover:z-10 hover:scale-110 hover:shadow-2xl hover:shadow-black/60 sm:w-[180px]"
    >
      {title.poster ? (
        <Image
          src={title.poster}
          alt={title.title}
          fill
          sizes="180px"
          className="object-cover"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-panel px-2 text-center text-xs text-chrome/50">
          {title.title}
        </div>
      )}
      <div className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-black/90 via-black/0 to-black/0 p-2 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
        <p className="font-display text-xs font-medium leading-tight text-white">
          {title.title}
        </p>
        <div className="flex items-center gap-1.5 text-[11px] text-chrome/70">
          {title.ageRating && (
            <span className="rounded border border-chrome/50 px-1 text-[10px]">
              {title.ageRating}
            </span>
          )}
          {title.year && <span>{title.year}</span>}
        </div>
      </div>
    </Link>
  );
}
