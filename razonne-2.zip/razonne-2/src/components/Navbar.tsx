"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useProfiles } from "@/lib/profile-context";
import { useAuth } from "@/lib/auth-context";

export default function Navbar() {
  const { activeProfile } = useProfiles();
  const { isAdmin } = useAuth();
  const [solid, setSolid] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 8);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 z-40 flex w-full items-center justify-between px-4 py-3 transition-colors duration-300 md:px-10 md:py-4 ${
        solid ? "bg-void/95 backdrop-blur" : "bg-gradient-to-b from-black/80 to-transparent"
      }`}
    >
      <div className="flex items-center gap-8">
        <Link href="/browse" className="flex items-center">
          <Image
            src="/logo-symbol.png"
            alt="Razonne+"
            width={34}
            height={34}
            priority
          />
        </Link>
        <nav className="hidden gap-6 text-sm text-chrome/90 md:flex">
          <Link href="/browse" className="hover:text-white">
            Início
          </Link>
          <Link href="/minha-lista" className="hover:text-white">
            A minha lista
          </Link>
          {isAdmin && (
            <Link href="/admin" className="hover:text-white">
              Gerir catálogo
            </Link>
          )}
        </nav>
      </div>

      <div className="flex items-center gap-4 md:gap-5">
        <Link
          href="/pesquisa"
          aria-label="Pesquisar"
          className="text-chrome hover:text-white"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            className="h-5 w-5"
          >
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.5-3.5" strokeLinecap="round" />
          </svg>
        </Link>

        <Link href="/profiles" className="flex items-center gap-2">
          {activeProfile ? (
            <>
              <Image
                src={activeProfile.avatar}
                alt={activeProfile.name}
                width={32}
                height={32}
                className="rounded-md"
              />
              <span className="hidden text-sm text-chrome sm:inline">
                {activeProfile.name}
              </span>
            </>
          ) : (
            <span className="rounded border border-chrome/40 px-3 py-1 text-sm text-chrome hover:border-teal">
              Perfis
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
