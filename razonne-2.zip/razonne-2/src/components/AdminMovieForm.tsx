"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import {
  saveTitle,
  deleteTitle,
  uploadImage,
  createMuxUpload,
  checkMuxStatus
} from "@/lib/catalog";
import type { Title, MuxStatus } from "@/lib/types";

const CATEGORIAS_SUGERIDAS = [
  "Em alta",
  "Ação",
  "Comédia",
  "Drama",
  "Terror",
  "Animação",
  "Documentário",
  "Romance"
];

const AGE_RATINGS = ["Livre", "10+", "12+", "14+", "16+", "18+"];

const STATUS_LABEL: Record<MuxStatus, string> = {
  sem_video: "Sem vídeo",
  a_enviar: "A enviar…",
  a_processar: "A processar no Mux…",
  pronto: "Pronto ✓",
  erro: "Erro no processamento"
};

export default function AdminMovieForm({ existing }: { existing?: Title }) {
  const router = useRouter();
  const [title, setTitleField] = useState(existing?.title ?? "");
  const [description, setDescription] = useState(existing?.description ?? "");
  const [poster, setPoster] = useState(existing?.poster ?? "");
  const [backdrop, setBackdrop] = useState(existing?.backdrop ?? "");
  const [genres, setGenres] = useState(existing?.genres.join(", ") ?? "");
  const [year, setYear] = useState(existing?.year?.toString() ?? "");
  const [durationMinutes, setDurationMinutes] = useState(
    existing?.durationMinutes?.toString() ?? ""
  );
  const [ageRating, setAgeRating] = useState(existing?.ageRating ?? "");
  const [category, setCategory] = useState(existing?.category ?? "Em alta");
  const [featured, setFeatured] = useState(existing?.featured ?? false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [posterUploading, setPosterUploading] = useState(false);
  const [backdropUploading, setBackdropUploading] = useState(false);

  const [videoProgress, setVideoProgress] = useState<number | null>(null);
  const [muxStatus, setMuxStatus] = useState<MuxStatus>(
    existing?.muxStatus ?? "sem_video"
  );
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Enquanto o vídeo está a ser processado no Mux, consulta o estado
  // periodicamente para atualizar o painel sem precisar de recarregar.
  useEffect(() => {
    if (!existing) return;
    if (muxStatus === "a_processar" || muxStatus === "a_enviar") {
      pollRef.current = setInterval(async () => {
        try {
          const updated = await checkMuxStatus(existing.id);
          setMuxStatus(updated.muxStatus);
          if (updated.muxStatus === "pronto" || updated.muxStatus === "erro") {
            if (pollRef.current) clearInterval(pollRef.current);
          }
        } catch (err) {
          console.error(err);
        }
      }, 4000);
      return () => {
        if (pollRef.current) clearInterval(pollRef.current);
      };
    }
  }, [existing, muxStatus]);

  async function handleImageUpload(
    file: File,
    kind: "poster" | "backdrop"
  ) {
    const setUploading = kind === "poster" ? setPosterUploading : setBackdropUploading;
    const setUrl = kind === "poster" ? setPoster : setBackdrop;
    setUploading(true);
    setError(null);
    try {
      const url = await uploadImage(file, kind);
      setUrl(url);
    } catch (err: any) {
      setError(err?.message ?? "Falha ao enviar imagem.");
    } finally {
      setUploading(false);
    }
  }

  async function handleVideoUpload(file: File) {
    if (!existing) return;
    setError(null);
    setVideoProgress(0);
    try {
      const { uploadId, uploadUrl } = await createMuxUpload(existing.id);
      await putWithProgress(uploadUrl, file, setVideoProgress);
      setMuxStatus("a_processar");
      setVideoProgress(null);
    } catch (err: any) {
      setError(err?.message ?? "Falha ao enviar o vídeo.");
      setVideoProgress(null);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!title.trim()) {
      setError("O título é obrigatório.");
      return;
    }
    setBusy(true);
    try {
      const saved = await saveTitle(
        {
          title: title.trim(),
          description: description.trim(),
          poster: poster.trim(),
          backdrop: backdrop.trim(),
          genres: genres
            .split(",")
            .map((g) => g.trim())
            .filter(Boolean),
          year: year ? Number(year) : undefined,
          durationMinutes: durationMinutes ? Number(durationMinutes) : undefined,
          ageRating: ageRating || undefined,
          category: category.trim() || "Em alta",
          featured
        },
        existing?.id
      );
      if (existing) {
        router.push("/admin");
        router.refresh();
      } else {
        // Filme criado — segue para a página de edição para adicionares
        // poster, banner e vídeo (podes fazê-lo agora ou mais tarde).
        router.push(`/admin/editar/${saved.id}`);
        router.refresh();
      }
    } catch (err: any) {
      setError(err?.message ?? "Não foi possível guardar.");
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete() {
    if (!existing) return;
    if (!confirm(`Apagar "${existing.title}" do catálogo?`)) return;
    setBusy(true);
    try {
      await deleteTitle(existing.id);
      router.push("/admin");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex max-w-2xl flex-col gap-4">
      <Field label="Título *">
        <input
          required
          value={title}
          onChange={(e) => setTitleField(e.target.value)}
          className={inputClass}
        />
      </Field>

      <Field label="Descrição / sinopse">
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          className={inputClass}
        />
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <ImageField
          label="Poster (vertical)"
          hint="Podes adicionar agora ou mais tarde."
          url={poster}
          uploading={posterUploading}
          onFile={(f) => handleImageUpload(f, "poster")}
          aspect="aspect-[2/3]"
        />
        <ImageField
          label="Banner / destaque (horizontal)"
          hint="Usado no topo da página inicial e na página do filme."
          url={backdrop}
          uploading={backdropUploading}
          onFile={(f) => handleImageUpload(f, "backdrop")}
          aspect="aspect-video"
        />
      </div>

      {existing ? (
        <div className="rounded-lg border border-chrome/15 bg-black/20 p-4">
          <p className="mb-1 text-sm font-medium text-chrome/90">Vídeo (Mux)</p>
          <p className="mb-3 text-xs text-chrome/50">
            Estado: <span className="text-chrome/80">{STATUS_LABEL[muxStatus]}</span>
          </p>
          <input
            type="file"
            accept="video/*"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleVideoUpload(f);
            }}
            className="block text-sm text-chrome/80 file:mr-3 file:rounded file:border-0 file:bg-razonne-gradient file:px-4 file:py-2 file:font-semibold file:text-black"
          />
          {videoProgress !== null && (
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded bg-chrome/15">
              <div
                className="h-full bg-teal transition-all"
                style={{ width: `${videoProgress}%` }}
              />
            </div>
          )}
        </div>
      ) : (
        <p className="text-xs text-chrome/50">
          Depois de guardares o filme, vais poder enviar o vídeo (Mux), o
          poster e o banner na página de edição.
        </p>
      )}

      <div className="grid grid-cols-2 gap-4">
        <Field label="Ano">
          <input
            value={year}
            onChange={(e) => setYear(e.target.value)}
            inputMode="numeric"
            className={inputClass}
          />
        </Field>
        <Field label="Duração (minutos)">
          <input
            value={durationMinutes}
            onChange={(e) => setDurationMinutes(e.target.value)}
            inputMode="numeric"
            className={inputClass}
          />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Field label="Classificação etária">
          <select
            value={ageRating}
            onChange={(e) => setAgeRating(e.target.value)}
            className={inputClass}
          >
            <option value="">—</option>
            {AGE_RATINGS.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Géneros" hint="Separados por vírgula">
          <input
            value={genres}
            onChange={(e) => setGenres(e.target.value)}
            placeholder="Terror, Drama"
            className={inputClass}
          />
        </Field>
      </div>

      <Field label="Categoria / fila" hint="Nome da fila onde o filme aparece na página inicial.">
        <input
          list="categorias"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className={inputClass}
        />
        <datalist id="categorias">
          {CATEGORIAS_SUGERIDAS.map((c) => (
            <option key={c} value={c} />
          ))}
        </datalist>
      </Field>

      <label className="flex items-center gap-2 text-sm text-chrome/90">
        <input
          type="checkbox"
          checked={featured}
          onChange={(e) => setFeatured(e.target.checked)}
          className="h-4 w-4 accent-teal"
        />
        Mostrar em destaque no topo da página inicial
      </label>

      {error && <p className="text-sm text-magenta">{error}</p>}

      <div className="mt-2 flex flex-wrap gap-3">
        <button
          type="submit"
          disabled={busy}
          className="rounded bg-razonne-gradient px-6 py-2.5 font-display font-semibold text-black transition hover:opacity-90 disabled:opacity-50"
        >
          {busy ? "A guardar…" : existing ? "Guardar alterações" : "Adicionar filme"}
        </button>
        {existing && (
          <button
            type="button"
            onClick={handleDelete}
            disabled={busy}
            className="rounded border border-magenta/60 px-6 py-2.5 font-medium text-magenta transition hover:bg-magenta/10 disabled:opacity-50"
          >
            Apagar filme
          </button>
        )}
      </div>
    </form>
  );
}

function putWithProgress(
  url: string,
  file: File,
  onProgress: (pct: number) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", url);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(new Error("O Mux recusou o envio do vídeo."));
    };
    xhr.onerror = () => reject(new Error("Falha de rede ao enviar o vídeo."));
    xhr.send(file);
  });
}

const inputClass =
  "w-full rounded bg-black/40 px-4 py-3 text-sm text-white outline-none ring-1 ring-chrome/20 focus:ring-teal";

function Field({
  label,
  hint,
  children
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-chrome/90">{label}</span>
      {children}
      {hint && <span className="text-xs text-chrome/50">{hint}</span>}
    </label>
  );
}

function ImageField({
  label,
  hint,
  url,
  uploading,
  onFile,
  aspect
}: {
  label: string;
  hint?: string;
  url: string;
  uploading: boolean;
  onFile: (file: File) => void;
  aspect: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-sm font-medium text-chrome/90">{label}</span>
      <div
        className={`relative ${aspect} w-full overflow-hidden rounded-md bg-black/40 ring-1 ring-chrome/20`}
      >
        {url && <Image src={url} alt={label} fill className="object-cover" />}
        {uploading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-xs text-chrome">
            A enviar…
          </div>
        )}
      </div>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
        }}
        className="block text-xs text-chrome/70 file:mr-3 file:rounded file:border-0 file:bg-chrome/20 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-white hover:file:bg-chrome/30"
      />
      {hint && <span className="text-xs text-chrome/50">{hint}</span>}
    </div>
  );
}
