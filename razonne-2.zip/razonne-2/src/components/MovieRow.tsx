"use client";

import { useRef } from "react";
import type { Title } from "@/lib/types";
import MovieCard from "@/components/MovieCard";

export default function MovieRow({
  label,
  titles
}: {
  label: string;
  titles: Title[];
}) {
  const scrollerRef = useRef<HTMLDivElement>(null);

  function scrollBy(amount: number) {
    scrollerRef.current?.scrollBy({ left: amount, behavior: "smooth" });
  }

  if (!titles.length) return null;

  return (
    <section className="relative py-3">
      <h2 className="mb-2 px-4 font-display text-lg font-medium text-chrome md:px-10">
        {label}
      </h2>

      <button
        aria-label={`Recuar em ${label}`}
        onClick={() => scrollBy(-600)}
        className="absolute left-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-gradient-to-r from-void to-transparent text-2xl text-white/80 hover:text-teal md:flex"
      >
        ‹
      </button>

      <div
        ref={scrollerRef}
        className="row-scroll flex gap-2 overflow-x-auto scroll-smooth px-4 md:gap-3 md:px-10"
      >
        {titles.map((t) => (
          <MovieCard key={t.id} title={t} />
        ))}
      </div>

      <button
        aria-label={`Avançar em ${label}`}
        onClick={() => scrollBy(600)}
        className="absolute right-0 top-10 z-10 hidden h-[calc(100%-2.5rem)] w-10 items-center justify-center bg-gradient-to-l from-void to-transparent text-2xl text-white/80 hover:text-teal md:flex"
      >
        ›
      </button>
    </section>
  );
}
