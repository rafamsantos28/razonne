"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import { getAllTitles } from "@/lib/catalog";
import { useAuth } from "@/lib/auth-context";
import type { Title } from "@/lib/types";

export default function AdminPage() {
  const { user, loading: authLoading, isGuest, isAdmin } = useAuth();
  const [titles, setTitles] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAdmin) return;
    getAllTitles()
      .then(setTitles)
      .finally(() => setLoading(false));
  }, [isAdmin]);

  if (authLoading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-void">
        <p className="text-chrome">A carregar…</p>
      </main>
    );
  }

  if (!isAdmin) {
    return (
      <main className="min-h-screen bg-void">
        <Navbar />
        <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
          <h1 className="font-display text-2xl font-semibold">
            Acesso restrito
          </h1>
          <p className="mt-2 max-w-sm text-sm text-chrome/70">
            {isGuest || !user
              ? "Inicia sessão com o email de administrador para gerir o catálogo."
              : "Esta conta não tem acesso ao painel de administração."}
          </p>
          <Link
            href="/login"
            className="mt-6 rounded bg-razonne-gradient px-6 py-2.5 font-display font-semibold text-black hover:opacity-90"
          >
            Iniciar sessão
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />
      <div className="px-4 pt-24 md:px-10 md:pt-28">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <h1 className="font-display text-2xl font-semibold md:text-3xl">
            Gerir catálogo
          </h1>
          <Link
            href="/admin/novo"
            className="rounded bg-razonne-gradient px-5 py-2.5 text-sm font-display font-semibold text-black hover:opacity-90"
          >
            + Adicionar filme
          </Link>
        </div>

        {loading ? (
          <p className="text-chrome">A carregar…</p>
        ) : titles.length === 0 ? (
          <p className="max-w-sm text-sm text-chrome/60">
            Ainda não adicionaste nenhum filme. Usa o botão acima para
            começar.
          </p>
        ) : (
          <div className="flex flex-col divide-y divide-chrome/10 rounded-lg bg-panel/50">
            {titles.map((t) => (
              <Link
                key={t.id}
                href={`/admin/editar/${t.id}`}
                className="flex items-center gap-4 px-4 py-3 transition hover:bg-panel"
              >
                <span className="relative h-16 w-11 shrink-0 overflow-hidden rounded bg-black/40">
                  {t.poster && (
                    <Image src={t.poster} alt={t.title} fill className="object-cover" />
                  )}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-medium text-white">
                    {t.title}
                  </span>
                  <span className="block truncate text-xs text-chrome/60">
                    {t.category} {t.year ? `· ${t.year}` : ""}
                    {t.featured ? " · Destaque" : ""}
                  </span>
                </span>
                <span className="text-chrome/40">Editar →</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
