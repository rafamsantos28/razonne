"use client";

import Link from "next/link";
import Navbar from "@/components/Navbar";
import AdminMovieForm from "@/components/AdminMovieForm";
import { useAuth } from "@/lib/auth-context";

export default function NewMoviePage() {
  const { isAdmin, loading } = useAuth();

  if (loading) return null;

  if (!isAdmin) {
    return (
      <main className="min-h-screen bg-void">
        <Navbar />
        <div className="flex min-h-screen items-center justify-center">
          <p className="text-chrome">
            Acesso restrito.{" "}
            <Link href="/login" className="text-teal hover:underline">
              Iniciar sessão
            </Link>
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />
      <div className="px-4 pt-24 md:px-10 md:pt-28">
        <Link href="/admin" className="text-sm text-chrome/60 hover:text-chrome">
          ← Voltar ao catálogo
        </Link>
        <h1 className="mb-6 mt-2 font-display text-2xl font-semibold md:text-3xl">
          Adicionar filme
        </h1>
        <AdminMovieForm />
      </div>
    </main>
  );
}
