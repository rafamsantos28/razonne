"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import Navbar from "@/components/Navbar";
import AdminMovieForm from "@/components/AdminMovieForm";
import { getTitle } from "@/lib/catalog";
import { useAuth } from "@/lib/auth-context";
import type { Title } from "@/lib/types";

export default function EditMoviePage() {
  const { id } = useParams<{ id: string }>();
  const { isAdmin, loading } = useAuth();
  const [title, setTitle] = useState<Title | null>(null);

  useEffect(() => {
    if (isAdmin) getTitle(id).then(setTitle);
  }, [isAdmin, id]);

  if (loading) return null;

  if (!isAdmin) {
    return (
      <main className="min-h-screen bg-void">
        <Navbar />
        <div className="flex min-h-screen items-center justify-center">
          <p className="text-chrome">
            Acesso restrito.{" "}
            <Link href="/login" className="text-teal hover:underline">
              Iniciar sessão
            </Link>
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />
      <div className="px-4 pt-24 md:px-10 md:pt-28">
        <Link href="/admin" className="text-sm text-chrome/60 hover:text-chrome">
          ← Voltar ao catálogo
        </Link>
        <h1 className="mb-6 mt-2 font-display text-2xl font-semibold md:text-3xl">
          Editar filme
        </h1>
        {title ? (
          <AdminMovieForm existing={title} />
        ) : (
          <p className="text-chrome">A carregar…</p>
        )}
      </div>
    </main>
  );
}
