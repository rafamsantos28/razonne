import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { sql, ensureSchema } from "@/lib/db";

export async function POST(req: NextRequest) {
  const { email, password } = await req.json().catch(() => ({}));

  if (typeof email !== "string" || typeof password !== "string") {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }

  const cleanEmail = email.trim().toLowerCase();
  if (!/^\S+@\S+\.\S+$/.test(cleanEmail)) {
    return NextResponse.json({ error: "Email inválido." }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json(
      { error: "A palavra-passe deve ter pelo menos 6 caracteres." },
      { status: 400 }
    );
  }

  await ensureSchema();

  const existing = await sql`SELECT id FROM users WHERE email = ${cleanEmail} LIMIT 1;`;
  if (existing.rows.length > 0) {
    return NextResponse.json({ error: "Este email já está registado." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  await sql`
    INSERT INTO users (email, password_hash) VALUES (${cleanEmail}, ${passwordHash});
  `;

  return NextResponse.json({ ok: true });
}
