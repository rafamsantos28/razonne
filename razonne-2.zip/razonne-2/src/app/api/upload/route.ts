import { NextRequest, NextResponse } from "next/server";
import { put } from "@vercel/blob";
import { resolveOwner } from "@/lib/owner";

export const runtime = "nodejs";

const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/avif"]);
const MAX_BYTES = 8 * 1024 * 1024; // 8MB chega de sobra para posters/banners

/**
 * Recebe uma imagem (poster ou banner) e guarda-a no Vercel Blob, devolvendo
 * o URL público final. Usado pelo painel /admin — o poster e o banner podem
 * ser adicionados na criação do filme ou mais tarde, a qualquer momento.
 */
export async function POST(req: NextRequest) {
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  const kind = (form?.get("kind") as string) || "imagem";

  if (!file || !(file instanceof File)) {
    return NextResponse.json({ error: "Ficheiro em falta." }, { status: 400 });
  }
  if (!ALLOWED_TYPES.has(file.type)) {
    return NextResponse.json(
      { error: "Formato inválido. Usa JPG, PNG, WEBP ou AVIF." },
      { status: 400 }
    );
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "Imagem demasiado grande (máx. 8MB)." }, { status: 400 });
  }

  const ext = file.type.split("/")[1];
  const key = `${kind}/${crypto.randomUUID()}.${ext}`;

  const blob = await put(key, file, {
    access: "public",
    contentType: file.type
  });

  return NextResponse.json({ url: blob.url });
}
