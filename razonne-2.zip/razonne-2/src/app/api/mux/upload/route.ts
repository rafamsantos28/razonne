import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";
import { createDirectUpload } from "@/lib/mux";

/**
 * Cria um "direct upload" no Mux para um título existente. O ficheiro de
 * vídeo é depois enviado diretamente do browser do admin para o URL
 * devolvido (não passa pelos nossos servidores/funções da Vercel, por isso
 * não há limite de tamanho de payload a preocupar).
 */
export async function POST(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const { titleId } = await req.json().catch(() => ({}));
  if (typeof titleId !== "string" || !titleId) {
    return NextResponse.json({ error: "titleId em falta." }, { status: 400 });
  }

  const existing = await sql`SELECT id FROM titles WHERE id = ${titleId} LIMIT 1;`;
  if (!existing.rows[0]) {
    return NextResponse.json({ error: "Título não encontrado." }, { status: 404 });
  }

  const { uploadId, uploadUrl } = await createDirectUpload();

  await sql`
    UPDATE titles
    SET mux_upload_id = ${uploadId}, mux_status = 'a_enviar', updated_at = now()
    WHERE id = ${titleId};
  `;

  return NextResponse.json({ uploadId, uploadUrl });
}
