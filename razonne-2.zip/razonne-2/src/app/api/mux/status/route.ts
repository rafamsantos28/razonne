import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";
import { getUpload, getAsset, publicPlaybackId } from "@/lib/mux";
import { rowToTitle } from "@/lib/title-row";

/**
 * Consultado em polling pelo painel /admin enquanto o vídeo está a ser
 * processado pelo Mux (alternativa simples ao webhook, que precisa de um
 * domínio público configurado no Mux Dashboard).
 */
export async function GET(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const titleId = req.nextUrl.searchParams.get("titleId");
  if (!titleId) {
    return NextResponse.json({ error: "titleId em falta." }, { status: 400 });
  }

  const { rows } = await sql`SELECT * FROM titles WHERE id = ${titleId} LIMIT 1;`;
  const row = rows[0];
  if (!row) {
    return NextResponse.json({ error: "Título não encontrado." }, { status: 404 });
  }

  // Já pronto — não vale a pena voltar a perguntar ao Mux.
  if (row.mux_status === "pronto" || !row.mux_upload_id) {
    return NextResponse.json({ title: rowToTitle(row) });
  }

  try {
    const upload = await getUpload(row.mux_upload_id);

    if (upload.status === "errored") {
      const { rows: updated } = await sql`
        UPDATE titles SET mux_status = 'erro', updated_at = now()
        WHERE id = ${titleId} RETURNING *;
      `;
      return NextResponse.json({ title: rowToTitle(updated[0]) });
    }

    if (!upload.asset_id) {
      // ainda a receber o ficheiro
      return NextResponse.json({ title: rowToTitle(row) });
    }

    const asset = await getAsset(upload.asset_id);
    const playbackId = publicPlaybackId(asset);

    if (asset.status === "ready" && playbackId) {
      const { rows: updated } = await sql`
        UPDATE titles SET
          mux_asset_id = ${upload.asset_id},
          mux_playback_id = ${playbackId},
          mux_status = 'pronto',
          duration_minutes = COALESCE(duration_minutes, ${
            asset.duration ? Math.round(asset.duration / 60) : null
          }),
          updated_at = now()
        WHERE id = ${titleId} RETURNING *;
      `;
      return NextResponse.json({ title: rowToTitle(updated[0]) });
    }

    if (asset.status === "errored") {
      const { rows: updated } = await sql`
        UPDATE titles SET mux_asset_id = ${upload.asset_id}, mux_status = 'erro', updated_at = now()
        WHERE id = ${titleId} RETURNING *;
      `;
      return NextResponse.json({ title: rowToTitle(updated[0]) });
    }

    // "preparing" — o Mux ainda está a transcodificar
    const { rows: updated } = await sql`
      UPDATE titles SET mux_asset_id = ${upload.asset_id}, mux_status = 'a_processar', updated_at = now()
      WHERE id = ${titleId} RETURNING *;
    `;
    return NextResponse.json({ title: rowToTitle(updated[0]) });
  } catch (err) {
    console.error("Erro a consultar o estado do Mux:", err);
    return NextResponse.json({ title: rowToTitle(row) });
  }
}
