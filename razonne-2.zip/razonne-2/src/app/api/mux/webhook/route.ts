import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { sql, ensureSchema } from "@/lib/db";
import { publicPlaybackId } from "@/lib/mux";

/**
 * Endpoint opcional: configura-o em Mux Dashboard → Settings → Webhooks
 * com o URL https://<o-teu-dominio>/api/mux/webhook para que os títulos
 * fiquem "prontos" assim que o Mux acabar de processar o vídeo, sem
 * depender do polling do painel /admin (útil se fechares o browser a meio
 * do processamento). Totalmente opcional — o polling em /api/mux/status
 * já trata disto sozinho enquanto o painel estiver aberto.
 */
export async function POST(req: NextRequest) {
  const raw = await req.text();
  const secret = process.env.MUX_WEBHOOK_SECRET;

  if (secret) {
    const signatureHeader = req.headers.get("mux-signature");
    if (!isValidSignature(raw, signatureHeader, secret)) {
      return NextResponse.json({ error: "Assinatura inválida." }, { status: 401 });
    }
  }

  const event = JSON.parse(raw);
  await ensureSchema();

  const uploadId: string | undefined =
    event.data?.upload_id ?? event.data?.id_upload;
  const assetId: string | undefined = event.data?.id ?? event.data?.asset_id;

  if (event.type === "video.asset.ready") {
    const playbackId = publicPlaybackId(event.data);
    if (assetId && playbackId) {
      await sql`
        UPDATE titles SET
          mux_playback_id = ${playbackId},
          mux_asset_id = ${assetId},
          mux_status = 'pronto',
          updated_at = now()
        WHERE mux_asset_id = ${assetId} OR mux_upload_id = ${uploadId ?? ""};
      `;
    }
  } else if (event.type === "video.asset.errored") {
    if (assetId) {
      await sql`
        UPDATE titles SET mux_status = 'erro', updated_at = now()
        WHERE mux_asset_id = ${assetId} OR mux_upload_id = ${uploadId ?? ""};
      `;
    }
  }

  return NextResponse.json({ ok: true });
}

function isValidSignature(
  rawBody: string,
  header: string | null,
  secret: string
): boolean {
  if (!header) return false;
  const parts = Object.fromEntries(
    header.split(",").map((p) => p.split("=") as [string, string])
  );
  if (!parts.t || !parts.v1) return false;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(`${parts.t}.${rawBody}`)
    .digest("hex");
  try {
    return crypto.timingSafeEqual(
      Buffer.from(expected),
      Buffer.from(parts.v1)
    );
  } catch {
    return false;
  }
}
