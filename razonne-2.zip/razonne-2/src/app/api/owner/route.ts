import { NextResponse } from "next/server";
import { resolveOwner, GUEST_COOKIE } from "@/lib/owner";

export async function GET() {
  const owner = await resolveOwner();
  const res = NextResponse.json({
    ownerId: owner.ownerId,
    isGuest: owner.isGuest,
    isAdmin: owner.isAdmin,
    email: owner.email
  });

  if (owner.guestIdToSet) {
    res.cookies.set(GUEST_COOKIE, owner.guestIdToSet, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 365 * 2,
      path: "/"
    });
  }

  return res;
}
