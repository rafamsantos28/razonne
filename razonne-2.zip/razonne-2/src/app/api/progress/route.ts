import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";

async function assertOwnsProfile(ownerId: string, profileId: string) {
  const { rows } = await sql`
    SELECT id FROM profiles WHERE id = ${profileId} AND owner_id = ${ownerId} LIMIT 1;
  `;
  return !!rows[0];
}

// GET /api/progress?profileId=...            -> todo o progresso do perfil
// GET /api/progress?profileId=...&titleId=... -> progresso de um título
export async function GET(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  const profileId = req.nextUrl.searchParams.get("profileId");
  const titleId = req.nextUrl.searchParams.get("titleId");

  if (!profileId || !(await assertOwnsProfile(owner.ownerId, profileId))) {
    return NextResponse.json({ error: "Perfil inválido." }, { status: 403 });
  }

  if (titleId) {
    const { rows } = await sql`
      SELECT title_id, seconds, duration_seconds, updated_at FROM watch_progress
      WHERE profile_id = ${profileId} AND title_id = ${titleId} LIMIT 1;
    `;
    const r = rows[0];
    return NextResponse.json({
      progress: r
        ? {
            titleId: r.title_id,
            seconds: r.seconds,
            durationSeconds: r.duration_seconds,
            updatedAt: Number(r.updated_at)
          }
        : null
    });
  }

  const { rows } = await sql`
    SELECT title_id, seconds, duration_seconds, updated_at FROM watch_progress
    WHERE profile_id = ${profileId} ORDER BY updated_at DESC;
  `;
  return NextResponse.json({
    progress: rows.map((r) => ({
      titleId: r.title_id,
      seconds: r.seconds,
      durationSeconds: r.duration_seconds,
      updatedAt: Number(r.updated_at)
    }))
  });
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  const body = await req.json().catch(() => null);
  const { profileId, titleId, seconds, durationSeconds } = body ?? {};

  if (
    !profileId ||
    !titleId ||
    typeof seconds !== "number" ||
    typeof durationSeconds !== "number"
  ) {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }
  if (!(await assertOwnsProfile(owner.ownerId, profileId))) {
    return NextResponse.json({ error: "Perfil inválido." }, { status: 403 });
  }

  await sql`
    INSERT INTO watch_progress (profile_id, title_id, seconds, duration_seconds, updated_at)
    VALUES (${profileId}, ${titleId}, ${seconds}, ${durationSeconds}, ${Date.now()})
    ON CONFLICT (profile_id, title_id) DO UPDATE SET
      seconds = EXCLUDED.seconds,
      duration_seconds = EXCLUDED.duration_seconds,
      updated_at = EXCLUDED.updated_at;
  `;

  return NextResponse.json({ ok: true });
}
