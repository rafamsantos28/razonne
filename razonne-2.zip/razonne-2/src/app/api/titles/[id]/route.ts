import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";
import { rowToTitle } from "@/lib/title-row";
import { deleteAsset } from "@/lib/mux";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  await ensureSchema();
  const { rows } = await sql`SELECT * FROM titles WHERE id = ${params.id} LIMIT 1;`;
  if (!rows[0]) {
    return NextResponse.json({ error: "Título não encontrado." }, { status: 404 });
  }
  return NextResponse.json({ title: rowToTitle(rows[0]) });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  await ensureSchema();
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  if (!body || !body.title?.trim()) {
    return NextResponse.json(
      { error: "O título é obrigatório." },
      { status: 400 }
    );
  }

  const { rows } = await sql`
    UPDATE titles SET
      title = ${body.title.trim()},
      description = ${body.description?.trim() ?? ""},
      poster_url = ${body.poster?.trim() ?? ""},
      backdrop_url = ${body.backdrop?.trim() ?? ""},
      genres = ${body.genres ?? []},
      year = ${body.year ?? null},
      duration_minutes = ${body.durationMinutes ?? null},
      age_rating = ${body.ageRating ?? null},
      category = ${body.category?.trim() || "Em alta"},
      featured = ${!!body.featured},
      updated_at = now()
    WHERE id = ${params.id}
    RETURNING *;
  `;

  if (!rows[0]) {
    return NextResponse.json({ error: "Título não encontrado." }, { status: 404 });
  }

  return NextResponse.json({ title: rowToTitle(rows[0]) });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  await ensureSchema();
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const { rows } = await sql`
    DELETE FROM titles WHERE id = ${params.id} RETURNING mux_asset_id;
  `;
  const assetId = rows[0]?.mux_asset_id;
  if (assetId) await deleteAsset(assetId);

  return NextResponse.json({ ok: true });
}
