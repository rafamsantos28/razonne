import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";
import { rowToTitle } from "@/lib/title-row";

export async function GET() {
  await ensureSchema();
  const { rows } = await sql`SELECT * FROM titles ORDER BY title ASC;`;
  return NextResponse.json({ titles: rows.map(rowToTitle) });
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  if (!owner.isAdmin) {
    return NextResponse.json({ error: "Acesso restrito." }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  if (!body || !body.title?.trim()) {
    return NextResponse.json(
      { error: "O título é obrigatório." },
      { status: 400 }
    );
  }

  const { rows } = await sql`
    INSERT INTO titles (
      title, description, poster_url, backdrop_url,
      genres, year, duration_minutes, age_rating, category, featured
    ) VALUES (
      ${body.title.trim()},
      ${body.description?.trim() ?? ""},
      ${body.poster.trim()},
      ${body.backdrop?.trim() ?? ""},
      ${body.genres ?? []},
      ${body.year ?? null},
      ${body.durationMinutes ?? null},
      ${body.ageRating ?? null},
      ${body.category?.trim() || "Em alta"},
      ${!!body.featured}
    )
    RETURNING *;
  `;

  return NextResponse.json({ title: rowToTitle(rows[0]) });
}
