import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner, GUEST_COOKIE } from "@/lib/owner";

const MAX_PROFILES = 5;

export async function GET() {
  await ensureSchema();
  const owner = await resolveOwner();

  const { rows } = await sql`
    SELECT id, name, avatar, is_kids FROM profiles
    WHERE owner_id = ${owner.ownerId}
    ORDER BY created_at ASC;
  `;

  const res = NextResponse.json({
    profiles: rows.map((r) => ({
      id: r.id,
      name: r.name,
      avatar: r.avatar,
      isKids: r.is_kids
    }))
  });
  applyGuestCookie(res, owner);
  return res;
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  const { name, avatar, isKids } = await req.json().catch(() => ({}));

  if (typeof name !== "string" || !name.trim()) {
    return NextResponse.json({ error: "Nome do perfil é obrigatório." }, { status: 400 });
  }
  if (typeof avatar !== "string" || !avatar.trim()) {
    return NextResponse.json({ error: "Escolhe um avatar." }, { status: 400 });
  }

  const countRes = await sql`
    SELECT COUNT(*)::int AS count FROM profiles WHERE owner_id = ${owner.ownerId};
  `;
  if (countRes.rows[0].count >= MAX_PROFILES) {
    return NextResponse.json(
      { error: `Já tens o máximo de ${MAX_PROFILES} perfis.` },
      { status: 400 }
    );
  }

  const { rows } = await sql`
    INSERT INTO profiles (owner_id, name, avatar, is_kids)
    VALUES (${owner.ownerId}, ${name.trim()}, ${avatar.trim()}, ${!!isKids})
    RETURNING id, name, avatar, is_kids;
  `;

  const res = NextResponse.json({
    profile: {
      id: rows[0].id,
      name: rows[0].name,
      avatar: rows[0].avatar,
      isKids: rows[0].is_kids
    }
  });
  applyGuestCookie(res, owner);
  return res;
}

function applyGuestCookie(
  res: NextResponse,
  owner: Awaited<ReturnType<typeof resolveOwner>>
) {
  if (owner.guestIdToSet) {
    res.cookies.set(GUEST_COOKIE, owner.guestIdToSet, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 365 * 2,
      path: "/"
    });
  }
  return res;
}
