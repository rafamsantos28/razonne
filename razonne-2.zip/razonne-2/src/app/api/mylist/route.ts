import { NextRequest, NextResponse } from "next/server";
import { sql, ensureSchema } from "@/lib/db";
import { resolveOwner } from "@/lib/owner";

async function assertOwnsProfile(ownerId: string, profileId: string) {
  const { rows } = await sql`
    SELECT id FROM profiles WHERE id = ${profileId} AND owner_id = ${ownerId} LIMIT 1;
  `;
  return !!rows[0];
}

// GET /api/mylist?profileId=... -> lista de titleIds guardados
export async function GET(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  const profileId = req.nextUrl.searchParams.get("profileId");

  if (!profileId || !(await assertOwnsProfile(owner.ownerId, profileId))) {
    return NextResponse.json({ error: "Perfil inválido." }, { status: 403 });
  }

  const { rows } = await sql`
    SELECT title_id FROM my_list WHERE profile_id = ${profileId} ORDER BY added_at DESC;
  `;
  return NextResponse.json({ titleIds: rows.map((r) => r.title_id) });
}

export async function POST(req: NextRequest) {
  await ensureSchema();
  const owner = await resolveOwner();
  const body = await req.json().catch(() => null);
  const { profileId, titleId, add } = body ?? {};

  if (!profileId || !titleId || typeof add !== "boolean") {
    return NextResponse.json({ error: "Dados inválidos." }, { status: 400 });
  }
  if (!(await assertOwnsProfile(owner.ownerId, profileId))) {
    return NextResponse.json({ error: "Perfil inválido." }, { status: 403 });
  }

  if (add) {
    await sql`
      INSERT INTO my_list (profile_id, title_id, added_at)
      VALUES (${profileId}, ${titleId}, ${Date.now()})
      ON CONFLICT (profile_id, title_id) DO NOTHING;
    `;
  } else {
    await sql`DELETE FROM my_list WHERE profile_id = ${profileId} AND title_id = ${titleId};`;
  }

  return NextResponse.json({ ok: true });
}
