import Image from "next/image";
import Link from "next/link";

export default function LandingPage() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-void px-6 text-center">
      <div className="pointer-events-none absolute inset-0 bg-razonne-glow" />

      <div className="relative z-10 flex flex-col items-center">
        <Image
          src="/logo-full.png"
          alt="Razonne+"
          width={420}
          height={130}
          priority
          className="mb-6 h-auto w-[260px] md:w-[380px]"
        />

        <p className="max-w-lg text-balance text-base text-chrome/90 md:text-lg">
          Os teus filmes e séries, sempre à mão. Sem planos, sem mensalidades —
          cria conta apenas se quiseres guardar o teu progresso entre
          dispositivos.
        </p>

        <div className="mt-9 flex flex-col gap-3 sm:flex-row">
          <Link
            href="/profiles"
            className="rounded bg-razonne-gradient px-8 py-3 font-display font-semibold text-black transition hover:opacity-90"
          >
            Continuar sem conta
          </Link>
          <Link
            href="/login"
            className="rounded border border-chrome/40 px-8 py-3 font-display font-semibold text-white transition hover:border-teal hover:text-teal"
          >
            Iniciar sessão / Criar conta
          </Link>
        </div>

        <p className="mt-10 max-w-md text-xs leading-relaxed text-chrome/50">
          Sem conta, o teu progresso e a tua lista ficam guardados apenas
          neste dispositivo. Com conta, sincronizam entre web, Android, iOS e
          TV.
        </p>
      </div>
    </main>
  );
}
