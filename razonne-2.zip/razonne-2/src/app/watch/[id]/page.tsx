"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import VideoPlayer from "@/components/VideoPlayer";
import { getTitle, getWatchProgress } from "@/lib/catalog";
import { useProfiles } from "@/lib/profile-context";
import type { Title } from "@/lib/types";

export default function WatchPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { activeProfile, loading: profilesLoading } = useProfiles();
  const [title, setTitle] = useState<Title | null>(null);
  const [startAt, setStartAt] = useState(0);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!profilesLoading && !activeProfile) router.replace("/profiles");
  }, [profilesLoading, activeProfile, router]);

  useEffect(() => {
    getTitle(id).then(setTitle);
  }, [id]);

  useEffect(() => {
    if (!activeProfile) return;
    getWatchProgress(activeProfile.id, id)
      .then((p) => {
        if (p && p.durationSeconds > 0 && p.seconds / p.durationSeconds < 0.95) {
          setStartAt(p.seconds);
        }
      })
      .finally(() => setReady(true));
  }, [activeProfile, id]);

  if (!title || !ready) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-black">
        <p className="text-chrome">A carregar…</p>
      </main>
    );
  }

  if (title.muxStatus !== "pronto" || !title.muxPlaybackId) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-black px-6 text-center">
        <p className="text-chrome">
          O vídeo de &quot;{title.title}&quot; ainda não está pronto para
          reprodução.
        </p>
        <Link href={`/title/${title.id}`} className="text-teal hover:underline">
          ← Voltar
        </Link>
      </main>
    );
  }

  return (
    <main className="relative min-h-screen bg-black">
      <Link
        href={`/title/${title.id}`}
        className="absolute left-4 top-4 z-20 rounded bg-black/50 px-3 py-1.5 text-sm text-white backdrop-blur transition hover:bg-black/70 md:left-8 md:top-6"
      >
        ← {title.title}
      </Link>
      <div className="flex h-screen items-center justify-center">
        <VideoPlayer title={title} startAt={startAt} activeProfileId={activeProfile!.id} />
      </div>
    </main>
  );
}
