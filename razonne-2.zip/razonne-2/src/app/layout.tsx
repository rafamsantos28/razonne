import type { Metadata } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import Providers from "./providers";

const display = Space_Grotesk({
  subsets: ["latin"],
  weight: ["500", "700"],
  variable: "--font-display"
});

const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  variable: "--font-body"
});

export const metadata: Metadata = {
  title: "Razonne+",
  description: "Os teus filmes e séries, num só sítio.",
  icons: { icon: "/favicon.png" }
};

// Todas as páginas dependem de quem está a usar o site (conta, convidado,
// perfis, progresso), por isso nunca devem ser pré-geradas como HTML
// estático no build — isto é decidido a cada pedido, no servidor.
export const dynamic = "force-dynamic";

export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-PT" className={`${display.variable} ${body.variable}`}>
      <body className="bg-void text-white font-body antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
