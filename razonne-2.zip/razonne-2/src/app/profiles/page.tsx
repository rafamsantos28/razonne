"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useProfiles } from "@/lib/profile-context";

const AVATARS = Array.from({ length: 10 }, (_, i) => `/avatars/avatar${i + 1}.png`);
const MAX_PROFILES = 5;

export default function ProfilesPage() {
  const router = useRouter();
  const { user, loading: authLoading, isGuest, logout } = useAuth();
  const { profiles, loading, selectProfile, createProfile } = useProfiles();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState(AVATARS[0]);
  const [isKids, setIsKids] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function choose(profileId: string) {
    selectProfile(profileId);
    router.push("/browse");
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setError(null);
    setBusy(true);
    try {
      // Cria o perfil, escolhe-o de imediato como perfil ativo e avança
      // logo para o catálogo — antes disto, o site ficava preso no ecrã de
      // perfis porque nada acontecia depois de "Criar" com sucesso.
      const created = await createProfile(name.trim(), avatar, isKids);
      selectProfile(created.id);
      router.push("/browse");
    } catch (err: any) {
      setError(err?.message ?? "Não foi possível criar o perfil. Tenta novamente.");
      setBusy(false);
    }
  }

  if (authLoading || loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-void">
        <p className="text-chrome">A carregar…</p>
      </main>
    );
  }

  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-void px-6 py-16">
      <div className="pointer-events-none absolute inset-0 bg-razonne-glow" />

      <h1 className="relative z-10 mb-10 font-display text-3xl font-semibold md:text-4xl">
        Quem está a ver?
      </h1>

      {!creating ? (
        <>
          <div className="relative z-10 flex flex-wrap justify-center gap-6">
            {profiles.map((p) => (
              <button
                key={p.id}
                onClick={() => choose(p.id)}
                className="group flex w-24 flex-col items-center gap-2 md:w-32"
              >
                <span className="relative block aspect-square w-full overflow-hidden rounded-lg ring-2 ring-transparent transition group-hover:scale-105 group-hover:ring-teal">
                  <Image src={p.avatar} alt={p.name} fill className="object-cover" />
                </span>
                <span className="flex items-center gap-1 text-sm text-chrome group-hover:text-white">
                  {p.name}
                  {p.isKids && <span title="Perfil infantil">🧒</span>}
                </span>
              </button>
            ))}

            {profiles.length < MAX_PROFILES && (
              <button
                onClick={() => setCreating(true)}
                className="flex w-24 flex-col items-center gap-2 md:w-32"
              >
                <span className="flex aspect-square w-full items-center justify-center rounded-lg border-2 border-dashed border-chrome/30 text-4xl text-chrome/40 transition hover:border-teal hover:text-teal">
                  +
                </span>
                <span className="text-sm text-chrome/70">Adicionar perfil</span>
              </button>
            )}
          </div>

          {profiles.length === 0 && (
            <p className="relative z-10 mt-6 max-w-sm text-center text-sm text-chrome/60">
              Ainda não tens nenhum perfil. Cria o primeiro para começar a ver
              filmes e séries.
            </p>
          )}

          {!isGuest && user && (
            <button
              onClick={() => logout().then(() => router.push("/"))}
              className="relative z-10 mt-10 text-xs text-chrome/50 hover:text-chrome"
            >
              Terminar sessão ({user.email})
            </button>
          )}
        </>
      ) : (
        <form
          onSubmit={handleCreate}
          className="relative z-10 w-full max-w-sm rounded-lg bg-panel/70 p-6 backdrop-blur"
        >
          <p className="mb-3 text-sm text-chrome/80">Escolhe um avatar</p>
          <div className="mb-5 grid grid-cols-5 gap-3">
            {AVATARS.map((a) => (
              <button
                type="button"
                key={a}
                onClick={() => setAvatar(a)}
                className={`relative aspect-square overflow-hidden rounded-md ring-2 transition ${
                  avatar === a ? "ring-teal" : "ring-transparent hover:ring-chrome/40"
                }`}
              >
                <Image src={a} alt="avatar" fill className="object-cover" />
              </button>
            ))}
          </div>

          <input
            required
            placeholder="Nome do perfil"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mb-3 w-full rounded bg-black/40 px-4 py-3 text-sm outline-none ring-1 ring-chrome/20 focus:ring-teal"
          />

          <label className="mb-4 flex items-center gap-2 text-sm text-chrome/80">
            <input
              type="checkbox"
              checked={isKids}
              onChange={(e) => setIsKids(e.target.checked)}
              className="h-4 w-4 accent-teal"
            />
            Perfil infantil
          </label>

          {error && <p className="mb-3 text-sm text-magenta">{error}</p>}

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => {
                setCreating(false);
                setError(null);
              }}
              className="flex-1 rounded border border-chrome/30 py-2.5 text-sm text-chrome hover:border-chrome/60"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={busy}
              className="flex-1 rounded bg-razonne-gradient py-2.5 text-sm font-semibold text-black hover:opacity-90 disabled:opacity-50"
            >
              {busy ? "A guardar…" : "Criar"}
            </button>
          </div>
        </form>
      )}
    </main>
  );
}
