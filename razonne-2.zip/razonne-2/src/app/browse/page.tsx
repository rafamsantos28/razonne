"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import MovieRow from "@/components/MovieRow";
import { useProfiles } from "@/lib/profile-context";
import { getAllTitles, getContinueWatching, groupByCategory } from "@/lib/catalog";
import type { Title } from "@/lib/types";

export default function BrowsePage() {
  const router = useRouter();
  const { activeProfile, loading: profilesLoading } = useProfiles();
  const [titles, setTitles] = useState<Title[]>([]);
  const [continueWatching, setContinueWatching] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profilesLoading && !activeProfile) {
      router.replace("/profiles");
    }
  }, [profilesLoading, activeProfile, router]);

  useEffect(() => {
    getAllTitles()
      .then(setTitles)
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!activeProfile || titles.length === 0) return;
    getContinueWatching(activeProfile.id, titles).then(setContinueWatching);
  }, [activeProfile, titles]);

  const featured = titles.find((t) => t.featured) ?? titles[0];
  const grouped = groupByCategory(titles);

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />

      {loading ? (
        <div className="flex h-[70vh] items-center justify-center">
          <p className="text-chrome">A carregar catálogo…</p>
        </div>
      ) : titles.length === 0 ? (
        <EmptyCatalog />
      ) : (
        <>
          {featured && <Hero title={featured} />}
          <div className="relative z-10 -mt-16 space-y-2 md:-mt-24">
            {continueWatching.length > 0 && (
              <MovieRow label="Continuar a ver" titles={continueWatching} />
            )}
            {Object.entries(grouped).map(([category, list]) => (
              <MovieRow key={category} label={category} titles={list} />
            ))}
          </div>
        </>
      )}
    </main>
  );
}

function EmptyCatalog() {
  return (
    <div className="flex h-[70vh] flex-col items-center justify-center px-6 text-center">
      <p className="font-display text-xl text-chrome">
        Ainda não há títulos no catálogo.
      </p>
      <p className="mt-2 max-w-sm text-sm text-chrome/60">
        Inicia sessão com o teu email de administrador e usa o painel{" "}
        <Link href="/admin" className="text-teal hover:underline">
          /admin
        </Link>{" "}
        para adicionar filmes — título, poster, banner e vídeo (via Mux).
      </p>
    </div>
  );
}
