"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { signIn } from "next-auth/react";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password })
        });
        const json = await res.json().catch(() => ({}));
        if (!res.ok) {
          setError(json?.error ?? "Não foi possível criar a conta.");
          setBusy(false);
          return;
        }
      }

      const result = await signIn("credentials", {
        email,
        password,
        redirect: false
      });

      if (result?.error) {
        setError("Email ou palavra-passe incorretos.");
        setBusy(false);
        return;
      }

      router.push("/profiles");
      router.refresh();
    } catch (err) {
      console.error(err);
      setError("Não foi possível concluir o pedido. Tenta novamente.");
      setBusy(false);
    }
  }

  return (
    <main className="relative flex min-h-screen items-center justify-center bg-void px-6">
      <div className="pointer-events-none absolute inset-0 bg-razonne-glow" />

      <div className="relative z-10 w-full max-w-sm rounded-lg bg-panel/80 p-8 backdrop-blur">
        <Link href="/" className="mb-6 flex justify-center">
          <Image src="/logo-symbol.png" alt="Razonne+" width={44} height={44} />
        </Link>

        <h1 className="mb-6 text-center font-display text-2xl font-semibold">
          {mode === "login" ? "Iniciar sessão" : "Criar conta"}
        </h1>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          <input
            type="email"
            required
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="rounded bg-black/40 px-4 py-3 text-sm outline-none ring-1 ring-chrome/20 focus:ring-teal"
          />
          <input
            type="password"
            required
            minLength={6}
            placeholder="Palavra-passe"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="rounded bg-black/40 px-4 py-3 text-sm outline-none ring-1 ring-chrome/20 focus:ring-teal"
          />

          {error && <p className="text-sm text-magenta">{error}</p>}

          <button
            type="submit"
            disabled={busy}
            className="mt-2 rounded bg-razonne-gradient py-3 font-display font-semibold text-black transition hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Um momento…" : mode === "login" ? "Entrar" : "Criar conta"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-chrome/70">
          {mode === "login" ? "Ainda não tens conta?" : "Já tens conta?"}{" "}
          <button
            onClick={() => {
              setMode(mode === "login" ? "signup" : "login");
              setError(null);
            }}
            className="text-teal hover:underline"
          >
            {mode === "login" ? "Criar conta" : "Iniciar sessão"}
          </button>
        </p>

        <Link
          href="/profiles"
          className="mt-4 block text-center text-xs text-chrome/50 hover:text-chrome"
        >
          Continuar sem conta
        </Link>
      </div>
    </main>
  );
}
