"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import { getTitle, getMyList, toggleMyList } from "@/lib/catalog";
import { useProfiles } from "@/lib/profile-context";
import type { Title } from "@/lib/types";

export default function TitleDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { activeProfile, loading: profilesLoading } = useProfiles();
  const [title, setTitle] = useState<Title | null>(null);
  const [inList, setInList] = useState(false);

  useEffect(() => {
    if (!profilesLoading && !activeProfile) router.replace("/profiles");
  }, [profilesLoading, activeProfile, router]);

  useEffect(() => {
    getTitle(id).then(setTitle);
  }, [id]);

  useEffect(() => {
    if (!activeProfile) return;
    getMyList(activeProfile.id).then((list) => setInList(list.includes(id)));
  }, [activeProfile, id]);

  async function handleToggleList() {
    if (!activeProfile) return;
    await toggleMyList(activeProfile.id, id, !inList);
    setInList(!inList);
  }

  if (!title) {
    return (
      <main className="min-h-screen bg-void">
        <Navbar />
      </main>
    );
  }

  const canPlay = title.muxStatus === "pronto" && !!title.muxPlaybackId;

  return (
    <main className="min-h-screen bg-void pb-20">
      <Navbar />

      <div className="relative h-[50vh] min-h-[320px] w-full bg-panel">
        {(title.backdrop || title.poster) && (
          <Image
            src={title.backdrop || title.poster}
            alt={title.title}
            fill
            priority
            className="object-cover object-top"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/40 to-transparent" />
      </div>

      <div className="relative z-10 -mt-24 px-4 md:px-10">
        <h1 className="font-display text-3xl font-bold md:text-5xl">
          {title.title}
        </h1>

        <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-chrome/80">
          {title.ageRating && (
            <span className="rounded border border-chrome/40 px-2 py-0.5 text-xs font-semibold">
              {title.ageRating}
            </span>
          )}
          {title.year && <span>{title.year}</span>}
          {title.durationMinutes && <span>{title.durationMinutes} min</span>}
          {title.genres.length > 0 && <span>{title.genres.join(" · ")}</span>}
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          {canPlay ? (
            <Link
              href={`/watch/${title.id}`}
              className="flex items-center gap-2 rounded bg-white px-6 py-2.5 font-medium text-black hover:bg-white/85"
            >
              ▶ Reproduzir
            </Link>
          ) : (
            <span className="flex items-center gap-2 rounded bg-chrome/20 px-6 py-2.5 font-medium text-chrome/70">
              {title.muxStatus === "a_processar" || title.muxStatus === "a_enviar"
                ? "A processar vídeo…"
                : "Vídeo em breve"}
            </span>
          )}
          <button
            onClick={handleToggleList}
            className="rounded border border-chrome/40 px-6 py-2.5 font-medium text-white hover:border-teal hover:text-teal"
          >
            {inList ? "✓ Na minha lista" : "+ Minha lista"}
          </button>
        </div>

        <p className="mt-6 max-w-2xl text-sm leading-relaxed text-chrome/90 md:text-base">
          {title.description}
        </p>
      </div>
    </main>
  );
}
