"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import MovieCard from "@/components/MovieCard";
import { getAllTitles } from "@/lib/catalog";
import { useProfiles } from "@/lib/profile-context";
import type { Title } from "@/lib/types";

export default function SearchPage() {
  const router = useRouter();
  const { activeProfile, loading: profilesLoading } = useProfiles();
  const [titles, setTitles] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (!profilesLoading && !activeProfile) router.replace("/profiles");
  }, [profilesLoading, activeProfile, router]);

  useEffect(() => {
    getAllTitles()
      .then(setTitles)
      .finally(() => setLoading(false));
  }, []);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return [];
    return titles.filter(
      (t) =>
        t.title.toLowerCase().includes(term) ||
        t.description?.toLowerCase().includes(term) ||
        t.genres?.some((g) => g.toLowerCase().includes(term))
    );
  }, [q, titles]);

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />
      <div className="px-4 pt-24 md:px-10 md:pt-28">
        <div className="mx-auto max-w-xl">
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Pesquisar filmes por título, género…"
            className="w-full rounded bg-panel px-5 py-3.5 text-white outline-none ring-1 ring-chrome/20 focus:ring-teal"
          />
        </div>

        {loading ? (
          <p className="mt-10 text-center text-chrome">A carregar…</p>
        ) : q.trim() && results.length === 0 ? (
          <p className="mt-10 text-center text-chrome/70">
            Sem resultados para &quot;{q}&quot;.
          </p>
        ) : (
          <div className="mt-10 flex flex-wrap justify-center gap-3 md:justify-start">
            {results.map((t) => (
              <MovieCard key={t.id} title={t} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
