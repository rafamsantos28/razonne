"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Navbar from "@/components/Navbar";
import MovieCard from "@/components/MovieCard";
import { getMyListTitles } from "@/lib/catalog";
import { useProfiles } from "@/lib/profile-context";
import type { Title } from "@/lib/types";

export default function MyListPage() {
  const router = useRouter();
  const { activeProfile, loading: profilesLoading } = useProfiles();
  const [titles, setTitles] = useState<Title[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profilesLoading && !activeProfile) router.replace("/profiles");
  }, [profilesLoading, activeProfile, router]);

  useEffect(() => {
    if (!activeProfile) return;
    getMyListTitles(activeProfile.id)
      .then(setTitles)
      .finally(() => setLoading(false));
  }, [activeProfile]);

  return (
    <main className="min-h-screen bg-void pb-24">
      <Navbar />
      <div className="px-4 pt-24 md:px-10 md:pt-28">
        <h1 className="mb-6 font-display text-2xl font-semibold md:text-3xl">
          A minha lista
        </h1>

        {loading ? (
          <p className="text-chrome">A carregar…</p>
        ) : titles.length === 0 ? (
          <p className="max-w-sm text-sm text-chrome/60">
            Ainda não adicionaste nenhum título à tua lista. Abre um filme e
            toca em &quot;+ Minha lista&quot;.
          </p>
        ) : (
          <div className="flex flex-wrap gap-3">
            {titles.map((t) => (
              <MovieCard key={t.id} title={t} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
