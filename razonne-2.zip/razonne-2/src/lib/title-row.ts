import type { Title } from "@/lib/types";

export function rowToTitle(r: any): Title {
  return {
    id: r.id,
    title: r.title,
    description: r.description ?? "",
    poster: r.poster_url ?? "",
    backdrop: r.backdrop_url ?? "",
    muxPlaybackId: r.mux_playback_id,
    muxAssetId: r.mux_asset_id,
    muxUploadId: r.mux_upload_id,
    muxStatus: r.mux_status ?? "sem_video",
    genres: r.genres ?? [],
    year: r.year ?? undefined,
    durationMinutes: r.duration_minutes ?? undefined,
    ageRating: r.age_rating ?? undefined,
    category: r.category ?? "Em alta",
    featured: !!r.featured
  };
}
