/**
 * Cliente mínimo para a API do Mux Video, usando apenas fetch (sem SDK) para
 * manter as dependências ao mínimo. Precisa das variáveis de ambiente
 * MUX_TOKEN_ID e MUX_TOKEN_SECRET (Mux Dashboard → Settings → Access Tokens).
 *
 * Usado apenas em código de servidor (rotas /api/mux/*) — nunca importar
 * isto num componente "use client".
 */

const MUX_API = "https://api.mux.com";

function authHeader() {
  const id = process.env.MUX_TOKEN_ID;
  const secret = process.env.MUX_TOKEN_SECRET;
  if (!id || !secret) {
    throw new Error(
      "Faltam as variáveis MUX_TOKEN_ID / MUX_TOKEN_SECRET. Define-as em Project Settings → Environment Variables na Vercel."
    );
  }
  return "Basic " + Buffer.from(`${id}:${secret}`).toString("base64");
}

async function muxFetch(path: string, init?: RequestInit) {
  const res = await fetch(`${MUX_API}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: authHeader(),
      ...(init?.headers ?? {})
    },
    cache: "no-store"
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(
      `Mux API ${path} devolveu ${res.status}: ${JSON.stringify(json)}`
    );
  }
  return json.data;
}

/** Cria um "direct upload": o browser do admin envia o ficheiro diretamente
 * para o Mux através do URL devolvido, sem passar pelo nosso servidor. */
export async function createDirectUpload() {
  const data = await muxFetch("/video/v1/uploads", {
    method: "POST",
    body: JSON.stringify({
      cors_origin: "*",
      new_asset_settings: {
        playback_policy: ["public"],
        video_quality: "basic"
      }
    })
  });
  return { uploadId: data.id as string, uploadUrl: data.url as string };
}

export async function getUpload(uploadId: string) {
  return muxFetch(`/video/v1/uploads/${uploadId}`);
}

export async function getAsset(assetId: string) {
  return muxFetch(`/video/v1/assets/${assetId}`);
}

export async function deleteAsset(assetId: string) {
  try {
    await muxFetch(`/video/v1/assets/${assetId}`, { method: "DELETE" });
  } catch {
    // já pode não existir — não bloqueia o resto do fluxo
  }
}

/** Extrai o playback ID "public" de um objeto asset devolvido pelo Mux. */
export function publicPlaybackId(asset: any): string | null {
  const pb = (asset?.playback_ids ?? []).find(
    (p: any) => p.policy === "public"
  );
  return pb?.id ?? null;
}
