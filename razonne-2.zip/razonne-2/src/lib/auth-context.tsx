"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode
} from "react";
import { useSession, signOut as nextAuthSignOut } from "next-auth/react";

type AuthContextValue = {
  user: { email: string } | null;
  loading: boolean;
  isGuest: boolean;
  isAdmin: boolean;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue>({
  user: null,
  loading: true,
  isGuest: true,
  isAdmin: false,
  logout: async () => {}
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const { data: session, status } = useSession();
  const [owner, setOwner] = useState<{
    isGuest: boolean;
    isAdmin: boolean;
    email: string | null;
  } | null>(null);

  const refreshOwner = useCallback(async () => {
    try {
      const res = await fetch("/api/owner");
      const json = await res.json();
      setOwner({
        isGuest: json.isGuest,
        isAdmin: json.isAdmin,
        email: json.email
      });
    } catch (err) {
      console.error("Falha a identificar o utilizador/convidado:", err);
      setOwner({ isGuest: true, isAdmin: false, email: null });
    }
  }, []);

  // Volta a resolver o "dono" sempre que a sessão de conta muda (login,
  // logout, ou o carregamento inicial do next-auth termina).
  useEffect(() => {
    if (status === "loading") return;
    refreshOwner();
  }, [status, session?.user, refreshOwner]);

  async function logout() {
    await nextAuthSignOut({ redirect: false });
    if (typeof window !== "undefined") {
      window.localStorage.removeItem("razonne:activeProfileId");
    }
    await refreshOwner();
  }

  const loading = status === "loading" || owner === null;
  const user = owner?.email ? { email: owner.email } : null;

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isGuest: owner?.isGuest ?? true,
        isAdmin: owner?.isAdmin ?? false,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
