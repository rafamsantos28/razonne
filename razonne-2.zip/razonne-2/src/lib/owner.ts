import { cookies } from "next/headers";
import { randomUUID } from "crypto";
import { getServerSession } from "next-auth";
import { authOptions, isAdminEmail } from "@/lib/auth";

export const GUEST_COOKIE = "razonne_guest_id";

/**
 * Identifica quem está a usar o site, tal como a Firebase fazia com sessões
 * anónimas: se houver conta iniciada, o "dono" é essa conta; caso
 * contrário, é um convidado identificado por um cookie httpOnly criado no
 * primeiro pedido (persiste neste dispositivo/navegador, tal como antes).
 */
export async function resolveOwner(): Promise<{
  ownerId: string;
  isGuest: boolean;
  isAdmin: boolean;
  email: string | null;
  guestIdToSet: string | null;
}> {
  const session = await getServerSession(authOptions);
  if (session?.user) {
    const uid = (session.user as any).id as string;
    return {
      ownerId: `user:${uid}`,
      isGuest: false,
      isAdmin: isAdminEmail(session.user.email),
      email: session.user.email ?? null,
      guestIdToSet: null
    };
  }

  const jar = cookies();
  const existing = jar.get(GUEST_COOKIE)?.value;
  const guestId = existing ?? randomUUID();

  return {
    ownerId: `guest:${guestId}`,
    isGuest: true,
    isAdmin: false,
    email: null,
    guestIdToSet: existing ? null : guestId
  };
}
