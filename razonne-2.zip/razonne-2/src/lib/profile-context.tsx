"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode
} from "react";
import { useAuth } from "@/lib/auth-context";
import type { Profile } from "@/lib/types";

const ACTIVE_PROFILE_KEY = "razonne:activeProfileId";

type ProfileContextValue = {
  profiles: Profile[];
  activeProfile: Profile | null;
  loading: boolean;
  selectProfile: (profileId: string) => void;
  createProfile: (
    name: string,
    avatar: string,
    isKids?: boolean
  ) => Promise<Profile>;
  refreshProfiles: () => Promise<void>;
};

const ProfileContext = createContext<ProfileContextValue>({
  profiles: [],
  activeProfile: null,
  loading: true,
  selectProfile: () => {},
  createProfile: async () => {
    throw new Error("ProfileProvider em falta.");
  },
  refreshProfiles: async () => {}
});

export function ProfileProvider({ children }: { children: ReactNode }) {
  // Não depende de haver conta — perfis funcionam também para convidados,
  // identificados por um cookie criado automaticamente pelo servidor.
  const { loading: authLoading } = useAuth();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeProfileId, setActiveProfileId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function refreshProfiles() {
    setLoading(true);
    try {
      const res = await fetch("/api/profiles");
      const json = await res.json();
      setProfiles(json.profiles ?? []);
    } catch (err) {
      console.error("Falha a carregar perfis:", err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (authLoading) return;
    refreshProfiles();
    const stored =
      typeof window !== "undefined"
        ? window.localStorage.getItem(ACTIVE_PROFILE_KEY)
        : null;
    if (stored) setActiveProfileId(stored);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading]);

  function selectProfile(profileId: string) {
    setActiveProfileId(profileId);
    if (typeof window !== "undefined") {
      window.localStorage.setItem(ACTIVE_PROFILE_KEY, profileId);
    }
  }

  async function createProfile(
    name: string,
    avatar: string,
    isKids = false
  ): Promise<Profile> {
    const res = await fetch("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, avatar, isKids })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      throw new Error(json?.error ?? "Não foi possível criar o perfil.");
    }
    const created: Profile = json.profile;
    setProfiles((prev) => [...prev, created]);
    return created;
  }

  const activeProfile = profiles.find((p) => p.id === activeProfileId) ?? null;

  return (
    <ProfileContext.Provider
      value={{
        profiles,
        activeProfile,
        loading,
        selectProfile,
        createProfile,
        refreshProfiles
      }}
    >
      {children}
    </ProfileContext.Provider>
  );
}

export function useProfiles() {
  return useContext(ProfileContext);
}
