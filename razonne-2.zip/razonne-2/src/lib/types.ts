export type Profile = {
  id: string;
  name: string;
  avatar: string; // e.g. "/avatars/avatar1.png"
  isKids?: boolean;
};

export type MuxStatus =
  | "sem_video" // nenhum vídeo enviado ainda
  | "a_enviar" // upload direto para o Mux em curso
  | "a_processar" // Mux está a preparar o asset (transcoding)
  | "pronto" // pronto para reprodução
  | "erro"; // o Mux reportou um erro no processamento

export type Title = {
  id: string;
  title: string;
  description: string;
  poster: string; // URL da imagem vertical (Vercel Blob)
  backdrop?: string; // URL da imagem horizontal/banner (Vercel Blob)
  muxAssetId?: string | null;
  muxPlaybackId?: string | null;
  muxUploadId?: string | null;
  muxStatus: MuxStatus;
  genres: string[];
  year?: number;
  durationMinutes?: number;
  ageRating?: string; // ex: "16+"
  category: string; // usado para agrupar em "filas" (ex: "Em alta", "Terror")
  featured?: boolean;
};

export type WatchProgress = {
  titleId: string;
  seconds: number;
  durationSeconds: number;
  updatedAt: number;
};
