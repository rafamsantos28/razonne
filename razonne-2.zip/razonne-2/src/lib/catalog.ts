"use client";

import type { Title, WatchProgress } from "@/lib/types";

async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) }
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json?.error ?? `Pedido a ${url} falhou (${res.status}).`);
  }
  return json;
}

// --- Catálogo -------------------------------------------------------------

export async function getAllTitles(): Promise<Title[]> {
  const { titles } = await api<{ titles: Title[] }>("/api/titles");
  return titles;
}

export async function getTitle(id: string): Promise<Title | null> {
  try {
    const { title } = await api<{ title: Title }>(`/api/titles/${id}`);
    return title;
  } catch {
    return null;
  }
}

export function groupByCategory(titles: Title[]): Record<string, Title[]> {
  return titles.reduce<Record<string, Title[]>>((acc, t) => {
    acc[t.category] = acc[t.category] ? [...acc[t.category], t] : [t];
    return acc;
  }, {});
}

// --- Gestão do catálogo (usado pelo painel /admin) -------------------------

export async function saveTitle(
  data: Omit<Title, "id" | "muxStatus">,
  id?: string
): Promise<Title> {
  const payload = {
    title: data.title,
    description: data.description,
    poster: data.poster,
    backdrop: data.backdrop,
    genres: data.genres,
    year: data.year,
    durationMinutes: data.durationMinutes,
    ageRating: data.ageRating,
    category: data.category,
    featured: data.featured
  };
  const { title } = await api<{ title: Title }>(
    id ? `/api/titles/${id}` : "/api/titles",
    { method: id ? "PUT" : "POST", body: JSON.stringify(payload) }
  );
  return title;
}

export async function deleteTitle(id: string): Promise<void> {
  await api(`/api/titles/${id}`, { method: "DELETE" });
}

export async function uploadImage(
  file: File,
  kind: "poster" | "backdrop"
): Promise<string> {
  const form = new FormData();
  form.append("file", file);
  form.append("kind", kind);
  const res = await fetch("/api/upload", { method: "POST", body: form });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.error ?? "Falha ao enviar imagem.");
  return json.url as string;
}

export async function createMuxUpload(
  titleId: string
): Promise<{ uploadId: string; uploadUrl: string }> {
  return api("/api/mux/upload", {
    method: "POST",
    body: JSON.stringify({ titleId })
  });
}

export async function checkMuxStatus(titleId: string): Promise<Title> {
  const { title } = await api<{ title: Title }>(
    `/api/mux/status?titleId=${titleId}`
  );
  return title;
}

// --- Progresso de visualização e "Minha lista" ----------------------------
// Ficam por perfil. A conta (ou o cookie de convidado) identifica o "dono"
// automaticamente no servidor — não é preciso passar o uid aqui.

export async function saveWatchProgress(
  profileId: string,
  progress: WatchProgress
) {
  await api("/api/progress", {
    method: "POST",
    body: JSON.stringify({
      profileId,
      titleId: progress.titleId,
      seconds: progress.seconds,
      durationSeconds: progress.durationSeconds
    })
  });
}

export async function getWatchProgress(
  profileId: string,
  titleId: string
): Promise<WatchProgress | null> {
  const { progress } = await api<{ progress: WatchProgress | null }>(
    `/api/progress?profileId=${profileId}&titleId=${titleId}`
  );
  return progress;
}

export async function toggleMyList(
  profileId: string,
  titleId: string,
  add: boolean
) {
  await api("/api/mylist", {
    method: "POST",
    body: JSON.stringify({ profileId, titleId, add })
  });
}

export async function getMyList(profileId: string): Promise<string[]> {
  const { titleIds } = await api<{ titleIds: string[] }>(
    `/api/mylist?profileId=${profileId}`
  );
  return titleIds;
}

export async function getMyListTitles(profileId: string): Promise<Title[]> {
  const [ids, all] = await Promise.all([getMyList(profileId), getAllTitles()]);
  const byId = new Map(all.map((t) => [t.id, t]));
  return ids.map((id) => byId.get(id)).filter((t): t is Title => !!t);
}

// Títulos com progresso guardado que ainda não terminaram, mais recentes
// primeiro — usado na fila "Continuar a ver".
export async function getContinueWatching(
  profileId: string,
  allTitles?: Title[]
): Promise<Title[]> {
  const [{ progress }, all] = await Promise.all([
    api<{ progress: WatchProgress[] }>(`/api/progress?profileId=${profileId}`),
    allTitles ? Promise.resolve(allTitles) : getAllTitles()
  ]);
  const byId = new Map(all.map((t) => [t.id, t]));
  const rows = progress
    .filter((p) => p.durationSeconds > 0 && p.seconds / p.durationSeconds < 0.95)
    .sort((a, b) => b.updatedAt - a.updatedAt);
  return rows.map((p) => byId.get(p.titleId)).filter((t): t is Title => !!t);
}
