/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    // Os posters/backdrops vêm do Vercel Blob (upload feito no painel
    // /admin). unoptimized=true evita ter de autorizar cada domínio uma a
    // uma e evita custos de otimização de imagem na Vercel.
    unoptimized: true,
    remotePatterns: [{ protocol: "https", hostname: "**" }]
  }
};

module.exports = nextConfig;
